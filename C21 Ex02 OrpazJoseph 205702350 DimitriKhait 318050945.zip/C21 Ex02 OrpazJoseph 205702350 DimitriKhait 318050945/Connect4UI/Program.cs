﻿namespace Connect4UI
{
    public class Program
    {
        public static void Main()
        {
            GameUI.welcomeScreen();
        }
    }
}